<footer class="footer">
  <a href="https://www.facebook.com/yanezmedicalclinic" target="_blank">
    <img src="images/fb_logo.png" alt="Facebook Logo" style="width:42px;height:42px;">
  </a>
  <p> Yañez X-Ray Medical Clinic and Laboratory. All rights reserved.</p>
</footer>
