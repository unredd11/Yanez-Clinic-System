<?php
session_start();

// Ensure patient is logged in
if (!isset($_SESSION['patient_id'])) {
    header("Location: login.php");
    exit();
}

require 'components/connect.php';

$patient_id = $_SESSION['patient_id'];

// --- Fetch results for this patient ---
$sql_results = "SELECT r.result_id, r.result_text, r.result_file, r.created_at,
                       a.service, a.appointment_date, a.appointment_time
                FROM results r
                JOIN appointment a ON r.appointment_id = a.appointment_id
                WHERE r.patient_id=? 
                ORDER BY r.created_at DESC";
$stmt = $conn->prepare($sql_results);
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$results = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Patient History</title>
  <link rel="stylesheet" href="css/yanezstyle.css">
</head>

<?php include 'header.php'; ?>

<body>

<main class="profile-dashboard">

  <!-- Appointment Tabs Section -->
  <section class="appointment-tabs-section">
    <h3>My Appointments</h3>

    <div class="tabs">
      <button class="tab-button active" onclick="showTab('request')">Request</button>
      <button class="tab-button" onclick="showTab('accepted')">Accepted</button>
      <button class="tab-button" onclick="showTab('declined')">Rejected</button>
    </div>

    <div id="request" class="tab-content active">
      <?php
        $sql_req = "SELECT service, appointment_date, appointment_time, status, appointment_details
                    FROM appointment WHERE patient_id = ? AND status = 'Pending'
                    ORDER BY appointment_date DESC, appointment_time DESC";
        $stmt = $conn->prepare($sql_req);
        $stmt->bind_param("i", $patient_id);
        $stmt->execute();
        $requests = $stmt->get_result();
      ?>
      <?php if ($requests->num_rows > 0): ?>
        <?php while ($row = $requests->fetch_assoc()): ?>
          <div class="appointment-card">
            <strong>Title:</strong> <?= htmlspecialchars($row['service']) ?><br>
            <span>Status: <?= htmlspecialchars($row['status']) ?></span><br>
            <small>Requested at: <?= htmlspecialchars($row['appointment_date'].' '.$row['appointment_time']) ?></small><br>
            <em><?= htmlspecialchars($row['appointment_details'] ?: '') ?></em>
          </div>
        <?php endwhile; ?>
      <?php else: ?>
        <p>No pending requests.</p>
      <?php endif; ?>
    </div>

    <div id="accepted" class="tab-content">
      <?php
        $sql_acc = "SELECT service, appointment_date, appointment_time, status, appointment_details
                    FROM appointment WHERE patient_id = ? AND status = 'Accepted'
                    ORDER BY appointment_date DESC, appointment_time DESC";
        $stmt = $conn->prepare($sql_acc);
        $stmt->bind_param("i", $patient_id);
        $stmt->execute();
        $accepted = $stmt->get_result();
      ?>
      <?php if ($accepted->num_rows > 0): ?>
        <?php while ($row = $accepted->fetch_assoc()): ?>
          <div class="appointment-card accepted">
            <strong>Title:</strong> <?= htmlspecialchars($row['service']) ?><br>
            <span>Status: <?= htmlspecialchars($row['status']) ?></span><br>
            <small>Accepted at: <?= htmlspecialchars($row['appointment_date'].' '.$row['appointment_time']) ?></small><br>
            <em><?= htmlspecialchars($row['appointment_details'] ?: '') ?></em>
          </div>
        <?php endwhile; ?>
      <?php else: ?>
        <p>No accepted appointments.</p>
      <?php endif; ?>
    </div>

    <div id="declined" class="tab-content">
      <?php
        $sql_dec = "SELECT service, appointment_date, appointment_time, status, appointment_details
                    FROM appointment WHERE patient_id = ? AND status IN ('Rejected', 'Declined')
                    ORDER BY appointment_date DESC, appointment_time DESC";
        $stmt = $conn->prepare($sql_dec);
        $stmt->bind_param("i", $patient_id);
        $stmt->execute();
        $declined = $stmt->get_result();
      ?>
      <?php if ($declined->num_rows > 0): ?>
        <?php while ($row = $declined->fetch_assoc()): ?>
          <div class="appointment-card declined">
            <strong>Title:</strong> <?= htmlspecialchars($row['service']) ?><br>
            <span>Status: <?= htmlspecialchars($row['status']) ?></span><br>
            <small>Updated at: <?= htmlspecialchars($row['appointment_date'].' '.$row['appointment_time']) ?></small><br>
            <em><?= htmlspecialchars($row['appointment_details'] ?: 'No reason provided') ?></em>
          </div>
        <?php endwhile; ?>
      <?php else: ?>
        <p>No Rejected appointments.</p>
      <?php endif; ?>
    </div>
  </section>

  <script>
  function showTab(tabId) {
    document.querySelectorAll('.tab-button').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
    document.querySelector(`[onclick="showTab('${tabId}')"]`).classList.add('active');
    document.getElementById(tabId).classList.add('active');
  }
  </script>

  <!-- RESULTS SECTION -->
  <section class="results-section">
    <h3>My Results / Prescriptions</h3>
    <?php if ($results->num_rows > 0): ?>
      <table class="results-table">
        <thead>
          <tr>
            <th>Service</th>
            <th>Appointment Date</th>
            <th>View PDF</th>
            <th>Released</th>
          </tr>
        </thead>
        <tbody>
          <?php while ($row = $results->fetch_assoc()): ?>
            <tr>
              <td><?= htmlspecialchars($row['service']) ?></td>
              <td><?= htmlspecialchars($row['appointment_date']) ?> <?= htmlspecialchars($row['appointment_time']) ?></td>
              <td>
                <?php if (!empty($row['result_file'])): ?>
                  <a href="patient_side/uploads/<?= htmlspecialchars($row['result_file']) ?>" target="_blank" class="view-btn">View PDF</a>
                <?php else: ?>
                  <span class="no-file">No file</span>
                <?php endif; ?>
              </td>
              <td><?= htmlspecialchars($row['created_at']) ?></td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    <?php else: ?>
      <p>No prescriptions or results available yet.</p>
    <?php endif; ?>
  </section>

<?php include 'footer.php'; ?>

<script>
function toggleNav() {
  var navMenu = document.getElementById('navMenu');
  if (navMenu) navMenu.classList.toggle('show');
}
</script>
</main>
</body>
</html>
